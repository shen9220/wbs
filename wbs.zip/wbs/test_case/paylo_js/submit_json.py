#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
from pathlib import Path
from typing import List , Dict , Any


def read_first_line_from_file ( file_path: Path ) -> str :
	"""从文本文件读取第一行内容，返回字符串"""
	try :
		with open ( file_path , 'r' , encoding='utf-8' ) as f :
			first_line = next ( (line.strip () for line in f if line.strip ()) , "" ).strip ()
			return first_line if first_line else ""
	except IOError as e :
		raise ValueError ( f"文件读取失败: {str ( e )}" )


class Liststr :
	pass


def read_txt_file ( file_path: Path ) -> Liststr :
	"""读取txt文件内容，按行分割，并返回字符串列表"""
	try :
		with open ( file_path , 'r' , encoding='utf-8' ) as f :
			content = f.read ().strip ()
			# 假设文件只有一行，且字段由 '|' 分隔
			return content.split ( '|' ) if content else []
	except Exception as e :
		print ( f"读取文件失败: {file_path}, 错误: {str ( e )}" )
		return []


# 读取所有需要的文件（示例路径，请根据实际情况修改）
zf_code_file = read_txt_file ( Path ( "/Users/admin/PycharmProjects/wbs/test_case/variable/erp/zf_code.txt" ) )
order_ids = [
	read_first_line_from_file ( Path ( "/Users/admin/PycharmProjects/wbs/test_case/variable/erp/order_ids.txt" ) )]
platform_id = [
	read_first_line_from_file ( Path ( "/Users/admin/PycharmProjects/wbs/test_case/variable/oms/sql_ids.txt" ) )]
zf_logistics_file = read_txt_file (
	Path ( "/Users/admin/PycharmProjects/wbs/test_case/variable/erp/zf_logistics.txt" ) )
zf_payment_file = read_txt_file ( Path ( "/Users/admin/PycharmProjects/wbs/test_case/variable/erp/zf_payment.txt" ) )
zf_payee_file = read_txt_file ( Path ( "/Users/admin/PycharmProjects/wbs/test_case/variable/erp/zf_payee.txt" ) )

# 验证读取结果
print ( "验证读取结果:" )
print ( f"zf_code_file: {zf_code_file}" )
print ( f"order_ids: {order_ids}" )
print ( f"zf_logistics_file: {zf_logistics_file}" )
print ( f"zf_payment_file: {zf_payment_file}" )
print ( f"zf_payee_file: {zf_payee_file}" )

# 原始JSON模板
payload_data = {
	"baseInfo" : {
		"id" : zf_code_file[0] ,
		"code" : zf_code_file[1] ,
		"associatedCode" : order_ids[0] ,
		"platformOrderId" : platform_id[0] ,
		"deliveryState" : "PENDING" ,
		"deliveryStateName" : "待工厂处理" ,
		"platform" : zf_code_file[2] ,
		"customerServiceMemo" : None ,
		"associatedCreator" : "沈友学" ,
		"firstDept" : None ,
		"secondDept" : None ,
		"thirdDept" : None ,
		"fourthDept" : None ,
		"customerExpectDeliveryDate" : None ,
		"expectDeliveryDate" : zf_code_file[3] ,
		"supplier" : "1806927319694172161" ,
		"supplierName" : "福建九家家居有限公司" ,
		"supplierShipmentAddressId" : "1806927320239431682" ,
		"supplierShipmentAddress" : "福建省福州市福清市宏路街道清华路融侨经济开发区\n内（福清华顺混合集成电路有限公司内）第10幢美福林家居" ,
		"shipmentDate" : None ,
		"merchandiser" : "0110,101" ,
		"merchandiserName" : "李旺,姚泽" ,
		"dispatcher" : "28" ,
		"dispatcherName" : "沈友学" ,
		"logisticsProviders" : None ,
		"logisticsProvidersName" : "" ,
		"memo" : None ,
		"afterSaleImages" : [] ,
		"fulfillmentOrderCreatedTime" : zf_code_file[4]
	} ,
	"logisticsInfo" : {
		"logisticsType" : zf_logistics_file[0] ,
		"logisticsTypeName" : zf_logistics_file[1] ,
		"logisticsChannel" : None ,
		"logisticsChannelName" : "" ,
		"logisticTrackingNumber" : "SF6045696907453" ,
		"logisticWaybillUrl" : "https://wbs-erp-test.oss-cn-hangzhou.aliyuncs.com/wbs-upload/2025-04-25/20250425021625_b60d033648a55dcb8f796fb8c4d03efd_578c86e3_1655_4276_b983_384625355660.jpeg" ,
		"logisticWaybillName" : "578c86e3-1655-4276-b983-384625355660.jpeg" ,
		"payEntity" : zf_payment_file[0] ,
		"payEntityName" : zf_payment_file[1] ,
		"logisticsEntity" : zf_payee_file[0] ,
		"logisticsEntityName" : zf_payee_file[1] ,
		"simulateLogisticsCost" : 10 ,
		"actualLogisticsCost" : None ,
		"costDifference" : None ,
		"confirmDate" : None ,
		"confirmMonth" : None ,
		"signDate" : None ,
		"isDownload" : False ,
		"logisticsOrderingDate" : None
	} ,
	"packingInfo" : {
		"actualLengthCm" : 12 ,
		"actualWidthCm" : 23 ,
		"actualHeightCm" : 34 ,
		"actualVolumeCbm" : 0.01 ,
		"actualWeightKg" : 45 ,
		"totalAmount" : 2706
	} ,
	"confirm" : True
}


def main () :
	try :
		# 输出最终JSON
		print ( json.dumps ( payload_data , indent=2 , ensure_ascii=False ) )
	except ValueError as e :
		print ( f"错误: {str ( e )}" )
	except Exception as e :
		print ( f"发生意外错误: {str ( e )}" )


if __name__ == "__main__" :
	main ()