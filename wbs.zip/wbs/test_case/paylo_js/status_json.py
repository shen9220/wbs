import json
from pathlib import Path
from typing import List  # 添加这行导入


def load_ids_from_file(file_path: Path) -> List[str]:
    """从文本文件读取平台订单ID列表"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip()]
    except IOError as e:
        raise ValueError(f"文件读取失败: {str(e)}")


# 原始JSON模板
json_template = {
    "page": 1,
    "pageSize": 1,
    "queryStrategy": 0,
    "fulfillmentOrderStatus": 10,
    "platformIds": ["1"],
    "platformOrderIdList": [],  # 此处留空待填充
    "amazonStoreList": [
        {
            "sellerId": "A2TBXYM10KKUFU",
            "marketplaceId": "ATVPDKIKX0DER",
            "storeName": "亚马逊16"
        }
    ]
}

# 从文件加载ID
try:
    txt_path = Path("/Users/admin/PycharmProjects/wbs/test_case/variable/oms/sql_ids.txt")
    json_template["platformOrderIdList"] = load_ids_from_file(txt_path)

    # 输出最终JSON
    print(json.dumps(json_template, indent=2, ensure_ascii=False))
except ValueError as e:
    print(f"错误: {str(e)}")
