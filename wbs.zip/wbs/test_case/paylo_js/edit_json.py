#!/usr/bin/python
# -*- coding:utf-8 -*-
import json
from pathlib import Path
from typing import List, Dict, Any

def load_ids_from_file(file_path: Path) -> str:
    """从文本文件读取平台订单ID，返回字符串"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            # 读取第一行并去除空白字符
            first_line = next((line.strip() for line in f if line.strip()), "")
            return first_line
    except IOError as e:
        raise ValueError(f"文件读取失败: {str(e)}")

def load_zf_code_from_file(file_path: Path) -> Dict[str, str]:
    """从zf_code.txt文件读取数据并解析为字典"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            if not content:
                raise ValueError("zf_code.txt文件内容为空")

            parts = content.split('|')
            if len(parts) < 3:
                raise ValueError("zf_code.txt文件格式不正确，需要至少3个字段")

            return {
                'id': parts[0],
                'code': parts[1],
                'platform': parts[2]
            }
    except IOError as e:
        raise ValueError(f"文件读取失败: {str(e)}")

# 原始JSON模板
payload_data = {
    "baseInfo": {
        "id": "",
        "code": "",
        "associatedCode": "",  # 修改为字符串类型
        "platformOrderId": "114-9763734-7650657",
        "deliveryState": "PENDING",
        "deliveryStateName": "待工厂处理",
        "platform": "",
        "customerServiceMemo": None,
        "associatedCreator": "沈友学",
        "firstDept": None,
        "secondDept": None,
        "thirdDept": None,
        "fourthDept": None,
        "customerExpectDeliveryDate": None,
        "expectDeliveryDate": "2025-04-25",
        "supplier": "1806927319694172161",
        "supplierName": "福建九家家居有限公司",
        "supplierShipmentAddressId": "1806927320239431682",
        "supplierShipmentAddress": None,
        "shipmentDate": None,
        "merchandiser": "0110,101",
        "merchandiserName": "李旺,姚泽",
        "dispatcher": None,
        "dispatcherName": None,
        "logisticsProviders": None,
        "logisticsProvidersName": "",
        "memo": None,
        "afterSaleImages": [],
        "fulfillmentOrderCreatedTime": "2025-04-24"
    },
    "logisticsInfo": {
        "logisticsType": None,
        "logisticsTypeName": "",
        "logisticsChannel": None,
        "logisticsChannelName": "",
        "logisticTrackingNumber": None,
        "payEntity": None,
        "payEntityName": "",
        "logisticsEntity": None,
        "logisticsEntityName": "",
        "simulateLogisticsCost": None,
        "actualLogisticsCost": None,
        "costDifference": None,
        "confirmDate": None,
        "confirmMonth": None,
        "signDate": None,
        "isDownload": False,
        "logisticsOrderingDate": None
    },
    "packingInfo": {
        "actualLengthCm": 12,
        "actualWidthCm": 23,
        "actualHeightCm": 34,
        "actualVolumeCbm": None,
        "actualWeightKg": 45,
        "totalAmount": 2706
    },
    "confirm": True
}

def main():
    try:
        # 从文件加载ID
        order_ids_path = Path("/Users/admin/PycharmProjects/wbs/test_case/variable/erp/order_ids.txt")
        payload_data["baseInfo"]["associatedCode"] = load_ids_from_file(order_ids_path)

        # 从文件加载zf_code
        zf_code_path = Path("/Users/admin/PycharmProjects/wbs/test_case/variable/erp/zf_code.txt")
        zf_code_data = load_zf_code_from_file(zf_code_path)

        # 更新JSON模板
        payload_data["baseInfo"]["id"] = zf_code_data['id']
        payload_data["baseInfo"]["code"] = zf_code_data['code']
        payload_data["baseInfo"]["platform"] = zf_code_data['platform']

        # 输出最终JSON
        print(json.dumps(payload_data, indent=2, ensure_ascii=False))

    except ValueError as e:
        print(f"错误: {str(e)}")
    except Exception as e:
        print(f"发生意外错误: {str(e)}")

if __name__ == "__main__":
    main()
