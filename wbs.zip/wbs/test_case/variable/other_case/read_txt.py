#!/usr/bin/python
# -*- coding:utf-8 -*-

'''
def read_order_ids ( file_path ) :
	"""从txt文件中读取order_ids"""
	try :
		with open ( file_path , 'r' , encoding='utf-8' ) as f :
			# 读取所有非空行并去除前后空白
			order_ids = [line.strip () for line in f if line.strip ()]
		return order_ids
	except FileNotFoundError :
		print ( f"错误：文件 {file_path} 不存在" )
		return []
	except Exception as e :
		print ( f"读取文件时出错: {str ( e )}" )
		return []

def read_zf_payee ( file_path ) :
	"""从txt文件中读取order_ids"""
	try :
		with open ( file_path , 'r' , encoding='utf-8' ) as f :
			# 读取所有非空行并去除前后空白
			order_ids = [line.strip () for line in f if line.strip ()]
		return order_ids
	except FileNotFoundError :
		print ( f"错误：文件 {file_path} 不存在" )
		return []
	except Exception as e :
		print ( f"读取文件时出错: {str ( e )}" )
		return []

# 新增：读取zf_code.txt文件中的参数
def read_zf_code_params ( file_path ) :
	"""从zf_code.txt读取id, code, platform参数"""
	try :
		with open ( file_path , 'r' , encoding='utf-8' ) as f :
			# 读取第一行并按空格/制表符分割
			line = f.readline ().strip ()
			if line :
				params = line.split ()
				# 确保至少有3个参数
				if len ( params ) >= 3 :
					return {
						'id' : params[0] ,
						'code' : params[1] ,
						'platform' : params[2]
					}
		return None
	except Exception as e :
		print ( f"读取zf_code.txt时出错: {str ( e )}" )
		return None


def read_zf_payment ( file_path ) :
	"""从txt文件中读取zf_payment"""
	try :
		with open ( file_path , 'r' , encoding='utf-8' ) as f :
			# 读取所有非空行并去除前后空白
			order_ids = [line.strip () for line in f if line.strip ()]
		return order_ids
	except FileNotFoundError :
		print ( f"错误：文件 {file_path} 不存在" )
		return []
	except Exception as e :
		print ( f"读取文件时出错: {str ( e )}" )
		return []


# 新增：读取zf_code.txt文件中的参数
def read_zf_logists ( file_path ) :
	"""从zf_code.txt读取id, code, platform参数"""
	try :
		with open ( file_path , 'r' , encoding='utf-8' ) as f :
			# 读取第一行并按空格/制表符分割
			line = f.readline ().strip ()
			if line :
				params = line.split ()
				# 确保至少有3个参数
				if len ( params ) >= 3 :
					return {
						'id' : params[0] ,
						'code' : params[1] ,
						'platform' : params[2]
					}
		return None
	except Exception as e :
		print ( f"读取zf_logists.txt时出错: {str ( e )}" )
		return None


# 新增：读取zf_payee参数
zf_payee_file = "/Users/admin/PycharmProjects/wbs/test_case/variable/zf_payee.txt"
zf_payee = read_zf_code_params ( zf_payee_file )

# 新增：读取zf_logistics参数
zf_logistics_file = "/Users/admin/PycharmProjects/wbs/test_case/variable/zf_logistics.txt"
zf_logistics = read_zf_code_params ( zf_logistics_file )

# 新增：读取zf_payment参数
zf_payment_file = "/Users/admin/PycharmProjects/wbs/test_case/variable/zf_payment.txt"
zf_payment = read_order_ids ( zf_payment_file )

if not zf_payment_file :
	print ( "警告：未读取到有效的zf_payment_file，程序将退出" )
	exit ( 1 )

# 新增：读取zf_code参数
zf_code_file = "/Users/admin/PycharmProjects/wbs/test_case/variable/zf_code.txt"
zf_code = read_zf_code_params ( zf_code_file )

# 新增：读取order_ids参数
order_ids_file = "/Users/admin/PycharmProjects/wbs/test_case/variable/order_ids.txt"
order_ids = read_order_ids ( order_ids_file )

if not order_ids :
	print ( "警告：未读取到有效的order_ids，程序将退出" )
	exit ( 1 )
'''