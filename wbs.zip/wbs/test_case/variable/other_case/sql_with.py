#!/usr/bin/python
# -*- coding:utf-8 -*-
import json
import pymysql
from pathlib import Path
from decimal import Decimal
from datetime import datetime , date


# 自定义JSON编码器处理Decimal和datetime类型
class CustomJSONEncoder ( json.JSONEncoder ) :
	def default ( self , obj ) :
		if isinstance ( obj , Decimal ) :
			return float ( obj )
		elif isinstance ( obj , (datetime , date) ) :
			return obj.isoformat ()
		return super ( CustomJSONEncoder , self ).default ( obj )


def parse_json_fields ( record ) :
	"""
	解析记录中可能包含JSON字符串的字段
	"""
	json_fields = ['address_info' , 'extend_info' , 'logistics_info']  # 需要自动解析的字段名
	
	for field in json_fields :
		if field in record and isinstance ( record[field] , str ) :
			try :
				record[field] = json.loads ( record[field] )
			except (json.JSONDecodeError , TypeError) :
				continue  # 解析失败保持原样
	return record


def execute_sql_to_json ( config , sql_query , output_json_path , target_field=None , output_txt_path=None ) :
	"""
	执行SQL查询并将结果转换为JSON格式，可选保存特定字段到TXT文件

	参数:
		config: 数据库连接配置(dict)
		sql_query: 要执行的SQL查询语句(str)
		output_json_path: JSON输出文件路径(str)
		target_field: 要提取的字段名(str)
		output_txt_path: TXT输出文件路径(str)
	"""
	try :
		# 1. 连接数据库并执行查询
		connection = pymysql.connect ( **config )
		with connection.cursor ( pymysql.cursors.DictCursor ) as cursor :
			cursor.execute ( sql_query )
			results = cursor.fetchall ()
		
		# 处理结果中的JSON字符串字段
		processed_results = [parse_json_fields ( record ) for record in results]
		
		# 打印查询结果（JSON格式）
		print ( "查询结果（已解析嵌套JSON）:" )
		print ( json.dumps ( processed_results , indent=2 , ensure_ascii=False , cls=CustomJSONEncoder ) )
		
		# 2. 将结果保存为JSON文件
		with open ( output_json_path , 'w' , encoding='utf-8' ) as json_file :
			json.dump ( processed_results , json_file , indent=2 , ensure_ascii=False , cls=CustomJSONEncoder )
		print ( f"\n成功保存JSON结果到: {output_json_path}" )
		
		# 3. 如果指定了目标字段，提取并保存到TXT
		if target_field and output_txt_path :
			field_values = []
			for item in processed_results :  # 使用处理后的结果
				if target_field in item :
					# 处理各种类型转换为字符串
					value = item[target_field]
					if isinstance ( value , (datetime , date) ) :
						field_values.append ( value.isoformat () )
					elif isinstance ( value , (dict , list) ) :  # 处理嵌套的JSON对象
						field_values.append ( json.dumps ( value , ensure_ascii=False ) )
					elif isinstance ( value , Decimal ) :
						field_values.append ( str ( float ( value ) ) )
					else :
						field_values.append ( str ( value ) )
			
			# 确保目录存在
			Path ( output_txt_path ).parent.mkdir ( parents=True , exist_ok=True )
			
			# 写入TXT文件(每行一个值)
			with open ( output_txt_path , 'w' , encoding='utf-8' ) as txt_file :
				txt_file.write ( '\n'.join ( field_values ) )
			print ( f"成功提取字段'{target_field}'到: {output_txt_path}" )
			
			# 打印TXT文件内容
			print ( "\nTXT文件内容:" )
			with open ( output_txt_path , 'r' , encoding='utf-8' ) as txt_file :
				print ( txt_file.read () )
		
		return True
	
	except pymysql.Error as e :
		print ( f"数据库错误: {str ( e )}" )
		return False
	except Exception as e :
		print ( f"其他错误: {str ( e )}" )
		return False
	finally :
		if 'connection' in locals () and connection.open :
			connection.close ()


# 示例用法
if __name__ == "__main__" :
	# 数据库配置
	db_config = {
		'host' : 'pc-bp1bq339oh50n6198.rwlb.rds.aliyuncs.com' ,
		'user' : 'wbs_oms_test' ,
		'password' : 'wbsOms@#2024' ,
		'database' : 'oms' ,
		'charset' : 'utf8mb4'
	}
	
	# SQL查询语句
	sql = "SELECT * FROM oms_platform_order WHERE `platform_order_id`='114-9763734-7650657'"
	
	# 输出文件路径
	json_file = "/Users/admin/PycharmProjects/wbs/test_case/variable/oms/sql_ids.json"
	txt_file = "/Users/admin/PycharmProjects/wbs/test_case/variable/oms/sql_ids.txt"
	
	# 执行并保存结果
	success = execute_sql_to_json (
		config=db_config ,
		sql_query=sql ,
		output_json_path=json_file ,
		target_field='platform_order_id' ,
		output_txt_path=txt_file
	)
	
	if success :
		print ( "\n操作成功完成！" )
	else :
		print ( "\n操作过程中出现错误" )
